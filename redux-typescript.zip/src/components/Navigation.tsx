import React, { useState } from 'react';

import { makeStyles } from '@material-ui/styles';
import AppBar from '@material-ui/core/AppBar';
import ToolBar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import AccountCircle from '@material-ui/icons/AccountCircle';
import Paper from '@material-ui/core/Paper';

const useStyles = makeStyles({
    root: {
        color: '#eee',
    },
    profile: {
        alignSelf: 'flex-end'
    },
    typo: {
        flexGrow: 1
    },
    dropdown: {
        padding: ' 5px 0px',
        position: 'absolute',
        right: '0px'
    },
    dropdownContainer: {
        position: 'relative'
    }
})

const Navigation = (): JSX.Element => {
    const classes = useStyles();
    const [open, setOpen] = useState<boolean>(false);
    const [menu, setMenu] = useState<boolean>(false)
    const handleOpen = () => {
        setOpen(!open);
    }

    const handleMenu = () => {
        setMenu(!menu)
    }

    return (
        <div>
            <AppBar position="static">
                <ToolBar>
                    <IconButton edge="start" color="inherit" aria-label="menu" onClick={handleMenu} className={menu ? 'animate' : ''}>
                        <MenuIcon />
                    </IconButton>
                    <Typography variant="h6" className={classes.typo}>
                        Admininstrator
                    </Typography>

                    <div className={classes.dropdownContainer}>
                        <IconButton
                            aria-label="account of current user"
                            aria-controls="menu-appbar"
                            aria-haspopup="true"
                            color="inherit"
                            onClick={handleOpen}
                        >
                            <AccountCircle />
                        </IconButton>

                        {open
                            ? <Paper className={classes.dropdown}>
                                <MenuItem onClick={handleOpen}>Profile</MenuItem>
                                <MenuItem onClick={handleOpen}>Logout</MenuItem>
                            </Paper>
                            : null}
                    </div>
                </ToolBar>
            </AppBar>
        </div>
    )
}

export default Navigation;