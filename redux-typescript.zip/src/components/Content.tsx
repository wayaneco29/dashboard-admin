import React from 'react';

import { Route, Switch, Link } from 'react-router-dom';

import { makeStyles } from '@material-ui/styles';
import Grid from '@material-ui/core/Grid';
import DashboardIcon from '@material-ui/icons/Dashboard';
import PeopleIcon from '@material-ui/icons/People';

import Dashboard from './Dashboard';
import User from './User';
import Settings from './Settings';

const useStyles = makeStyles({
    rootContainer: {
        height: 'calc(100vh - 64px)'
    },
    gridItem: {
        padding: '30px 20px'
    },
    linkContainer: {
        padding: '20px 0px',
        textDecoration: 'none',
        color: '#000'
    },
    links: {
        display: 'flex',
        alignItems: 'center',
        textDecoration: 'none',
        fontSize: '23px'
    },
    span: {
        paddingLeft: '14px',
        color: '#3f51b5'
    },
    linkColor: {
        color: '#3f51b5'
    }
})

const Content = (): JSX.Element => {
    const classes = useStyles();
    return (
        <Grid container className={classes.rootContainer}>
            <Grid item xs={2} className={classes.gridItem}>
                <div className={classes.linkContainer}>
                    <Link className={classes.links} to='/'>
                        <DashboardIcon fontSize='large' className={classes.linkColor} />
                        <span className={classes.span}>Dashboard</span>
                    </Link>
                </div>
                <div className={classes.linkContainer}>
                    <Link className={classes.links} to='/users'>
                        <PeopleIcon fontSize='large' className={classes.linkColor} />
                        <span className={classes.span}>Users</span>
                    </Link>
                </div>
                <div className={classes.linkContainer}>
                    <Link className={classes.links} to='/settings'>
                        <PeopleIcon fontSize='large' className={classes.linkColor} />
                        <span className={classes.span}>Settings</span>
                    </Link>
                </div>
            </Grid>
            <Grid item xs={10} className={classes.gridItem}>
                <Switch>
                    <Route exact path='/' component={Dashboard} />
                    <Route path='/users' component={User} />
                    <Route path='/settings' component={Settings} />
                </Switch>
            </Grid>
        </Grid>
    )
}

export default Content;