import React, { useState, useEffect } from 'react';

import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';

interface IState {
    id: number,
    name: string,
    email: string,
    address: {
        street: string
    },
    website: string,
    username: string,
    company: string
}

const useStyles = makeStyles({
    root: {
        padding: '30px'
    }
})

const User = () => {
    const [users, setUsers] = useState<IState[]>([])

    useEffect(() => {
        fetch('https://jsonplaceholder.typicode.com/users')
            .then(res => res.json())
            .then(data => setUsers(data))
    }, [])

    const classes = useStyles()
    return (
        <Paper className={classes.root}>
            <Table>
                <TableHead>
                    <TableRow>
                        <TableCell>ID</TableCell>
                        <TableCell align="center">NAME</TableCell>
                        <TableCell align="center">EMAIL</TableCell>
                        <TableCell align="center">ADDRESS</TableCell>
                        <TableCell align="center">WEBSITE</TableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {
                        users.map(user => (
                            <TableRow key={user.id}>
                                <TableCell component="th" scope="row">
                                    {user.id}
                                </TableCell>
                                <TableCell align="center">{user.name}</TableCell>
                                <TableCell align="center">{user.email}</TableCell>
                                <TableCell align="center">{user.address.street}</TableCell>
                                <TableCell align="center">{user.website}</TableCell>
                            </TableRow>
                        ))
                    }
                </TableBody>
            </Table>
        </Paper>
    )
}

export default User;