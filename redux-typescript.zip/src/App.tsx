import React from 'react';

import Navigation from './components/Navigation';
import Content from './components/Content';

interface IState {
  close?: string
}
class App extends React.Component<{}, IState> {
  state: IState = {
    close: ''
  }
  render() {
    return (
      <React.Fragment>
        <Navigation />
        <Content />
      </React.Fragment>
    )
  }
}
export default App;